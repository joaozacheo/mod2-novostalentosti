package introducao.avaliacao1;

public class Construtor extends Colaborador{
    private boolean terceirizado;

    public boolean isTerceirizado() {
        return terceirizado;
    }
    public void setTerceirizado(boolean terceirizado) {
        this.terceirizado = terceirizado;
    }
}
