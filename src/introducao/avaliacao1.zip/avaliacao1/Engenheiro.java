package introducao.avaliacao1;

public class Engenheiro extends Colaborador{
    private String formacao;

    public String getFormacao() {
        return formacao;
    }
    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }
}
